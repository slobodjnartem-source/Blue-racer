[app]
title = Blue Racer
package.name = blueracer
package.domain = org.openai.games
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 1.0
requirements = python3,pygame-ce
orientation = landscape
fullscreen = 1
icon.filename = %(source.dir)s/icon.png

[buildozer]
log_level = 2
warn_on_root = 1

[app:android]
android.permissions =
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
p4a.bootstrap = sdl2
p4a.local_recipes = ./p4a-recipes
