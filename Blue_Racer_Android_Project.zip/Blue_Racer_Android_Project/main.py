import pygame
import random
import sys

pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
W, H = screen.get_size()
clock = pygame.time.Clock()

WHITE = (255, 255, 255)
BLACK = (15, 15, 20)
GRAY = (65, 65, 70)
GREEN = (20, 145, 50)
BLUE = (35, 110, 240)
RED = (240, 40, 40)
YELLOW = (255, 210, 0)

font = pygame.font.SysFont("Arial", 25)
small_font = pygame.font.SysFont("Arial", 19)
big_font = pygame.font.SysFont("Arial", 40)

cars = [
    ("BMW M4", (30, 100, 230)),
    ("Mercedes", (190, 190, 200)),
    ("Audi", (230, 30, 30)),
    ("Lamborghini", (255, 210, 0)),
    ("Porsche", (0, 180, 100))
]

page = "menu"
selected_car = 0
spoiler = False
camera = 3

road_left = W // 8
road_width = W * 3 // 4
lane_width = road_width // 4

car_w = max(35, lane_width // 2)
car_h = car_w * 2

player_lane = 1.5
target_lane = 1.5
player_y = H - car_h - 150

left_held = False
right_held = False

enemies = []
score = 0
speed = 7
spawn_timer = 0
line_y = 0
game_over = False


def draw_text(txt, x, y, font_obj=font, color=WHITE):
    img = font_obj.render(str(txt), True, color)
    screen.blit(img, (int(x), int(y)))


def button(txt, x, y, w, h, color=BLUE):
    pygame.draw.rect(screen, color, (x, y, w, h), border_radius=12)
    img = font.render(txt, True, WHITE)
    screen.blit(img, img.get_rect(center=(x+w//2, y+h//2)))


def back_button():
    button("НАЗАД", 15, 15, 120, 55, GRAY)


def lane_x(lane):
    return int(road_left + lane*lane_width + (lane_width-car_w)//2)


def draw_car(x, y, color, with_spoiler=False, scale=1):
    w = max(12, int(car_w*scale))
    h = max(20, int(car_h*scale))
    x, y = int(x), int(y)

    pygame.draw.rect(screen, color, (x, y, w, h),
                     border_radius=max(3, int(8*scale)))
    pygame.draw.rect(screen, (120, 200, 255),
                     (x+w//6, y+h//5, max(4, w*2//3), max(5, h//5)),
                     border_radius=4)
    pygame.draw.rect(screen, (120, 200, 255),
                     (x+w//6, y+h*3//5, max(4, w*2//3), max(5, h//5)),
                     border_radius=4)

    wheel = max(3, w//8)
    for yy in (y+h//4, y+h*3//4):
        pygame.draw.rect(screen, BLACK, (x-wheel, yy, wheel, max(6, h//7)))
        pygame.draw.rect(screen, BLACK, (x+w, yy, wheel, max(6, h//7)))

    if with_spoiler:
        pygame.draw.rect(screen, BLACK,
                         (x-w//5, y+h-5, w+w//2, max(4, h//15)))


def restart():
    global player_lane, target_lane, enemies, score, speed
    global spawn_timer, line_y, game_over

    player_lane = 1.5
    target_lane = 1.5
    enemies = []
    score = 0
    speed = 7
    spawn_timer = 0
    line_y = 0
    game_over = False


def menu_screen():
    screen.fill((25, 30, 50))
    title = big_font.render("MY CAR GAME", True, WHITE)
    screen.blit(title, title.get_rect(center=(W//2, H//4)))
    button("ГРАТИ", W//2-130, H//2-40, 260, 75, GREEN)
    button("ВИЙТИ", W//2-130, H//2+65, 260, 75, RED)


def garage_screen():
    screen.fill((25, 30, 45))
    back_button()
    title = big_font.render("ГАРАЖ", True, WHITE)
    screen.blit(title, title.get_rect(center=(W//2, H//8)))

    for i, (name, color) in enumerate(cars):
        y = H//5+i*75
        draw_car(W//2-130, y, color,
                 spoiler if i == selected_car else False, 0.8)
        draw_text(name, W//2-30, y+15)
        if selected_car == i:
            draw_text("ВИБРАНО", W//2+110, y+15, small_font, YELLOW)

    button("СПОЙЛЕР: "+("ТАК" if spoiler else "НІ"),
           W//2-150, H-190, 300, 65,
           GREEN if spoiler else GRAY)
    button("ПОЧАТИ ГОНКУ", W//2-150, H-105, 300, 70, BLUE)


def draw_road():
    global line_y
    screen.fill(GREEN)
    pygame.draw.rect(screen, GRAY, (road_left, 0, road_width, H))

    for i in range(1, 4):
        x = road_left+i*lane_width
        for y in range(-100, H, 140):
            yy = (y+line_y) % (H+140)-140
            pygame.draw.rect(screen, WHITE, (x-4, yy, 8, 65))

    pygame.draw.rect(screen, WHITE, (road_left, 0, 5, H))
    pygame.draw.rect(screen, WHITE, (road_left+road_width-5, 0, 5, H))


def draw_first_person():
    screen.fill((100, 180, 235))
    pygame.draw.rect(screen, GREEN, (0, H//3, W, H))

    pygame.draw.polygon(screen, GRAY, [
        (W//2-road_width//7, H//3),
        (W//2+road_width//7, H//3),
        (W, H), (0, H)
    ])

    for i in range(1, 4):
        top_x = W//2 + (i-2)*road_width//14
        bottom_x = road_left+i*lane_width
        pygame.draw.polygon(screen, WHITE, [
            (top_x-2, H//3), (top_x+2, H//3),
            (bottom_x+5, H), (bottom_x-5, H)
        ])

    for e in enemies:
        progress = max(0, min(1, (e[1]+car_h)/(H+car_h)))
        scale = 0.25 + progress*0.85
        x = int(W//2 + (e[0]-1.5)*W//9) - max(12, int(car_w*scale))//2
        y = int(H//3 + progress*(H*0.48))
        draw_car(x, y, e[2], False, scale)

    pygame.draw.polygon(screen, cars[selected_car][1], [
        (W//3, H), (W*2//3, H),
        (W*3//5, H-120), (W*2//5, H-120)
    ])
    pygame.draw.rect(screen, BLACK, (0, H-65, W, 65))
    pygame.draw.circle(screen, WHITE, (W//2, H-35), 24, 5)


def update_race(dt):
    global player_lane, target_lane, score, speed
    global spawn_timer, line_y, game_over

    if game_over:
        return

    # Symmetric, smooth steering in both directions
    direction = int(right_held) - int(left_held)
    target_lane = max(0, min(3, target_lane + direction * 0.055 * dt))
    player_lane += (target_lane-player_lane) * min(1, 0.18*dt)

    line_y += speed*dt
    score += dt
    speed = min(13, 7+int(score)//600)

    spawn_timer += dt
    if spawn_timer > 85 and len(enemies) < 5:
        spawn_timer = 0
        possible = list(range(4))
        random.shuffle(possible)
        chosen = possible[0]
        for lane in possible:
            if not any(e[0] == lane and e[1] < car_h*3 for e in enemies):
                chosen = lane
                break
        enemies.append([chosen, -car_h,
                        random.choice([RED, YELLOW, GREEN,
                                       (180, 50, 220), WHITE])])

    for e in enemies:
        e[1] += speed*dt
    enemies[:] = [e for e in enemies if e[1] < H+car_h]

    for e in enemies:
        if abs(e[0]-player_lane) < 0.48:
            if camera == 3:
                if abs(e[1]-player_y) < car_h*0.8:
                    game_over = True
            elif e[1] > H-car_h*3:
                game_over = True


def race_screen():
    if camera == 3:
        draw_road()
        for e in enemies:
            draw_car(lane_x(e[0]), int(e[1]), e[2])

        if not game_over:
            px = road_left + player_lane*lane_width + (lane_width-car_w)//2
            draw_car(px, player_y, cars[selected_car][1], spoiler)
    else:
        draw_first_person()

    draw_text("SCORE: "+str(int(score)//10), 15, 20)
    draw_text("FPS: "+str(int(clock.get_fps())), 15, 55, small_font, YELLOW)

    button("<", 15, H-110, 105, 70)
    button(">", 130, H-110, 105, 70)
    button("КАМЕРА", W-155, H//2-40, 140, 75, (100, 70, 180))
    draw_text("ВИД: "+("3-Я ОСОБА" if camera == 3 else "1-ША ОСОБА"),
              W-210, H//2+45, small_font)

    if game_over:
        pygame.draw.rect(screen, BLACK, (W//2-170, H//2-90, 340, 190),
                         border_radius=20)
        draw_text("АВАРІЯ!", W//2-75, H//2-65, big_font, RED)
        draw_text("Рахунок: "+str(int(score)//10), W//2-80, H//2-15)
        button("ЗАНОВО", W//2-110, H//2+35, 220, 60, GREEN)


running = True
while running:
    dt = min(clock.tick(60)/16.67, 2.0)
    left_held = False
    right_held = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if page == "menu":
                    running = False
                elif page == "race":
                    page = "garage"
                else:
                    page = "menu"

            if page == "race":
                if event.key == pygame.K_LEFT:
                    target_lane = max(0, target_lane-1)
                if event.key == pygame.K_RIGHT:
                    target_lane = min(3, target_lane+1)

        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos

            if page == "menu":
                if H//2-40 < y < H//2+35:
                    page = "garage"
                elif H//2+65 < y < H//2+140:
                    running = False

            elif page == "garage":
                if x < 140 and y < 80:
                    page = "menu"
                elif H-195 < y < H-120:
                    spoiler = not spoiler
                elif y > H-115:
                    restart()
                    page = "race"
                else:
                    for i in range(len(cars)):
                        cy = H//5+i*75
                        if cy-10 < y < cy+65:
                            selected_car = i

            elif page == "race":
                if x > W-170 and H//2-45 < y < H//2+50:
                    camera = 1 if camera == 3 else 3
                elif game_over:
                    if H//2+25 < y < H//2+110:
                        restart()
                elif y > H-130:
                    if x < 120:
                        target_lane = max(0, target_lane-0.35)
                    elif x < 240:
                        target_lane = min(3, target_lane+0.35)

    # Hold steering buttons
    if page == "race" and not game_over and pygame.mouse.get_pressed()[0]:
        mx, my = pygame.mouse.get_pos()
        if my > H-130:
            if mx < 120:
                left_held = True
            elif 130 < mx < 240:
                right_held = True

    keys = pygame.key.get_pressed()
    if page == "race" and not game_over:
        if keys[pygame.K_LEFT]:
            left_held = True
        if keys[pygame.K_RIGHT]:
            right_held = True

    if page == "race":
        update_race(dt)

    if page == "menu":
        menu_screen()
    elif page == "garage":
        garage_screen()
    elif page == "race":
        race_screen()

    pygame.display.flip()

pygame.quit()
sys.exit()
